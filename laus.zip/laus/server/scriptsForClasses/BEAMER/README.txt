#! /bin/bash

Lösung funktioniert nicht
cp  files/clone		/usr/bin/
 
chmod 775 /usr/bin/clone

echo "clone" > /etc/X11/Xsession.d/45custom_xrandr-settings

chmod 644 /etc/X11/Xsession.d/45custom_xrandr-settings


neue Lösung:

Skript clone nach /usr/bin

Skript cloneslow noch /usr/bin

Skript setCloneMod.sh nach /etc/profil.d

alle ausführbar machen

Lösung für Loginscreen:

funktionierende Datei monitor.xml in .config nach /var/lib/ligthdm/.config kopieren 
