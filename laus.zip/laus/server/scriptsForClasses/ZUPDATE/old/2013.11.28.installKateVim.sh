#! /bin/bash

apt-get -y update
apt-get -y install kate
apt-get -y install vim

