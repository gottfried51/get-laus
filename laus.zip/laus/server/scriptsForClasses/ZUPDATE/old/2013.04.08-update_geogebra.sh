#! /bin/bash

apt-get -y update

apt-get -y install geogebra

