#! /bin/bash


rm /etc/apt/sources.list.d/geogebra.list

echo 'deb http://download.opensuse.org/repositories/home:heimdall78/xUbuntu_12.04/ /' > /etc/apt/sources.list.d/geogebra.list 
