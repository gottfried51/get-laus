#! /bin/bash

apt-get -y update

# Zipformat
apt-get -y install p7zip p7zip-full


