#! /bin/bash

apt-get -y update

apt-get -y dist-upgrade
