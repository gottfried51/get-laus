#! /bin/bash

apt-get -y remove geogebra

apt-get -y dist-upgrade
