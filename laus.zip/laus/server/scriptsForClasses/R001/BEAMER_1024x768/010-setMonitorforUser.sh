#! /bin/bash

cp  files/monitors.xml	/home/user.save/.config/