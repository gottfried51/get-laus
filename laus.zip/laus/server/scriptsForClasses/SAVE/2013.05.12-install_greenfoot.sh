#! /bin/bash

apt-get -y remove greenfoot

dpkg -i ../UBUNTU1204/files/greenfoot-230.deb