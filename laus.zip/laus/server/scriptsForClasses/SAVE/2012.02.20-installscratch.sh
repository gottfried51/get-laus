#! /bin/bash

apt-get -y update

# Scratch
apt-get -y install scratch