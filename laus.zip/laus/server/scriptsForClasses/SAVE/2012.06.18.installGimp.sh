#! /bin/bash

#apt-get update

#apt-get -y dist-upgrade

#/usr/share/doc/libdvdread4/install-css.sh

apt-get -y install gimp
