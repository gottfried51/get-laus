#! /bin/bash

apt-get -y remove mozilla-libreoffice