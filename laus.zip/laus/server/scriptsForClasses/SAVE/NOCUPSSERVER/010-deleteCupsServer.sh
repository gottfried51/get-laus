#! /bin/bash

rm  /etc/cups/client.conf
