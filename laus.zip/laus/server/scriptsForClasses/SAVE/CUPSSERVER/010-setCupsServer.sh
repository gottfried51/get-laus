#! /bin/bash

cp  files/client.conf		/etc/cups/
