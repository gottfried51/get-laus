#! /bin/bash

cp UBUNTU1204/files/user.save/.mozilla/firefox/7t6vinu7.default/places.sqlite /home/user.save/.mozilla/firefox/7t6vinu7.default/places.sqlite