#! /bin/bash

apt-get update

## Grafikprogramme nachinstalliert
apt-get -y install gimp
