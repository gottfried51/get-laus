#! /bin/bash

init 6