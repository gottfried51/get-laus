#! /bin/bash

#add-apt-repository -y ppa:gnome3-team/gnome3

apt-get -y update

apt-get -y install gnome-shell

