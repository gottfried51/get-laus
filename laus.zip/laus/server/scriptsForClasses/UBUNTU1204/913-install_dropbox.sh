#! /bin/bash

#apt-key adv --keyserver pgp.mit.edu --recv-keys 5044912E

apt-get -y update

apt-get --force-yes -y install nautilus-dropbox
