#! /bin/bash

apt-add-repository ppa:otto-kesselgulasch/gimp
apt-get -y update
apt-get -y install gimp