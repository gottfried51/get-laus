Achtung:
für Firefox Profil update muss Ordner .mozilla für others lesbar sein!
