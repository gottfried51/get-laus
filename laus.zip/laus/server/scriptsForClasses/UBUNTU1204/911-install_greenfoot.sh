#! /bin/bash

apt-get -y install openjdk-6-jdk

dpkg -i files/greenfoot-230.deb