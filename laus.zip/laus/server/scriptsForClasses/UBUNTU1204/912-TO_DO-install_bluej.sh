#! /bin/bash

apt-get --force-yes -y install nautilus-dropbox
