#! /bin/bash

dpkg -i files/geogebra_4.2.60.0-29146_all.deb