#! /bin/bash

cp  files/02proxy	/etc/apt/apt.conf.d/
 
chmod 644 /etc/apt/apt.conf.d/02proxy