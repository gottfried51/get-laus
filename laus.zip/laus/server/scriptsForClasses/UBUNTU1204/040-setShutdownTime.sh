#! /bin/bash

cp  files/shutDownAt22Clock		/etc/cron.hourly/
chmod 755 /etc/cron.hourly/shutDownAt22Clock