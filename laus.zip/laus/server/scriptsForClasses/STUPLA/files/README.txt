chrome.desktop nach .config/autostart kopieren 
