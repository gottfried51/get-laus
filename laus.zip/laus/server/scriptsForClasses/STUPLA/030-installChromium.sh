#! /bin/bash

apt-get update

apt-get -y install chromium-browser
