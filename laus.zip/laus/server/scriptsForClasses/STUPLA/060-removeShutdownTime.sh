#! /bin/bash

rm /etc/cron.hourly/shutDownAt22Clock